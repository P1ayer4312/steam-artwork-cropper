---
title: Canvas rendering
script: canvas.coffee
template: test.html
---

<p id="info">Loading...</p>

<img id="result">

